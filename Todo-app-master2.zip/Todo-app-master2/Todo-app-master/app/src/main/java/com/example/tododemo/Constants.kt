package com.example.tododemo

val CHANEL_ID = "chanelID"
val NOTIFICATION_ID = 1
val NOTIFICATION_TITLE = "title"
val NOTIFICATION_MESSAGE = "message"
val JOB_ID = 1001;
val FIRST_NAME = "firstName"
val LAST_NAME = "lastName"